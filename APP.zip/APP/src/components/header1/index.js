import React from "react";

import { useNavigation } from "@react-navigation/native";

import { View, Image, StyleSheet } from "react-native";

export default function Header1() {

    const navigation = useNavigation();
    return (

        <View style={styles.containerHeader}>
            <Image
                source={require('../../assets/img/logoPreto.png')}
                style={styles.headerImage}
            />
        </View>
    )

}

const styles = StyleSheet.create({
    containerHeader: {
        flex: 1,
        backgroundColor:''
        
    

    },

    headerImage: {
        marginTop:30,
        width: 130,
        height: 100,
        marginLeft: 'auto',
        marginRight: 'auto'
    }
})