import React, {useState} from "react";

import {  View, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import {Ionicons} from '@expo/vector-icons';

export default function InputSenha(valor, senha, altera, teclado){
    const [showPassword, setShowPassword] = useState(false); 

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword)
    }
    return (
      
        <View style={styles.input}>
            <TextInput
                style={styles.senha}
                placeholder={'Senha'}
                value={valor}
                onChangeText={altera}
                keyboardType={teclado}
                secureTextEntry={!showPassword}
            />
            <TouchableOpacity onPress={togglePasswordVisibility} style={styles.olho}>
                <Ionicons
                    name={showPassword ? 'eye-off' : 'eye'} 
                    size={25}
                    color="#B126E8" 
                />
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
input:{
    marginTop: 25,
    backgroundColor: '#D0D0D0',
    width: '70%',
    height:50,
    marginLeft: 'auto',
    marginRight: 'auto',
    borderRadius:12,
    flexDirection:'row',
    justifyContent:'space-between',
    paddingHorizontal: 10
    
},
    senha:{
        fontSize:20
    },

olho: {
    paddingVertical: 12
}


})