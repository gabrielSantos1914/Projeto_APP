import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Boasvindas from "../pages/boasVindas";
import InputSenha from "../components/inputSenha";

const Stack = createNativeStackNavigator();
export default function Routes(){
return(
<Stack.Navigator>

<Stack.Screen
name="InputSenha"
component={InputSenha}
options={{headerShown: false}}
/>




</Stack.Navigator>


)

}